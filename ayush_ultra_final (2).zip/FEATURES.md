Ayush features... (25 items)
1. Owner-only private mode
2. Personal memory
... (see full FEATURES.md in final package)
