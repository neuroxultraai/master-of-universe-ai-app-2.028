const input = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const chatBox = document.getElementById('chat-box');
const voiceBtn = document.getElementById('voice-btn');
const offlineToggle = document.getElementById('offline-mode');

function addMessage(sender, text) {
  const msg = document.createElement('div');
  msg.classList.add('message', sender);
  msg.textContent = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function getAIResponse(prompt) {
  const offline = offlineToggle.checked;
  if (offline) return "⚡ Offline Mode Active: Basic reasoning only.";
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    const data = await response.json();
    return data.reply;
  } catch {
    return "❌ Error connecting to AI server.";
  }
}

sendBtn.onclick = async () => {
  const text = input.value.trim();
  if (!text) return;
  addMessage('user', text);
  input.value = '';
  const reply = await getAIResponse(text);
  addMessage('bot', reply);
};

voiceBtn.onclick = () => {
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = 'en-IN';
  recognition.start();
  recognition.onresult = (event) => {
    input.value = event.results[0][0].transcript;
    sendBtn.click();
  };
};